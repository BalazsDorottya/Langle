public interface WordGuesser {
    void loadWords();

    String getRandomWord();
}
